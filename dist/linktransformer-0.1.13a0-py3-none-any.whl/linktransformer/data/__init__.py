
import os

# Define the directory path to the data folder
DATA_DIR_PATH = os.path.dirname(__file__)